 <footer>
    <div>
      <br>
      <p>&copy; 2025 Quatro Corações. Todos os direitos reservados.</p>
      <p>Contato: sacquatro@4coracoes.com.br</p>
      <br>
    </div>
  </footer>
  </body>
</html>