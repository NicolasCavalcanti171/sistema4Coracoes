<?php
include __DIR__.'/header.php';
session_start();

echo '<form method="post" action="">';
echo '<h2>Cadastro</h2>';
echo '<input type="email" name="email" placeholder="Email" required>';
echo '<input type="password" name="senha" placeholder="Senha" required>';
echo '<button type="submit">Cadastrar</button>';
echo '<p>Já tem login? <a href="login.php">Entre aqui</a></p>';
echo '</form>';


$host = 'localhost';
$db = 'sistemalogin';
$user = 'root';
$pass = 'root';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<p class='erro'>Email inválido!</p>";
    } else {
        $stmt = $conn->prepare("SELECT email FROM usuarios WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            echo "<p class='erro'>Email já cadastrado!</p>";
        } else {
            $stmt->close();
            $hash_senha = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO usuarios (email, senha) VALUES (?, ?)");
            $stmt->bind_param("ss", $email, $hash_senha);
            if ($stmt->execute()) {
                echo "<p class='sucesso'>Cadastro realizado com sucesso! <a href='login.php'>Faça login</a></p>";
            } else {
                echo "<p class='erro'>Erro ao cadastrar usuário.</p>";
            }
        }
        $stmt->close();
    }
}

$conn->close();
include __DIR__.'/footer.php';
?>
