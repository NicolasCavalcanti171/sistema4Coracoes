<?php
include __DIR__.'/header.php';
?>

<style>
    h1{
        color: #ffffff;
        font-size: 35px;
        text-align: center;
        font-family: 'Ysabeau Office', sans-serif;
}
</style>

<br><br><br><br><br><br><br><br><br>
<h1>Dados para Entrega</h1>

<form action="" method="POST">
    <label>Nome Completo</label>
    <input type="text" name="nome" required>

    <label>Telefone</label>
    <input type="text" name="telefone" required placeholder="(xx) xxxxx-xxxx">

    <label>Endereço</label>
    <input type="text" name="endereco" required placeholder="Rua / Avenida">

    <label>Número</label>
    <input type="text" name="numero" required>

    <label>Bairro</label>
    <input type="text" name="bairro" required>

    <label>CEP</label>
    <input type="text" name="cep" required placeholder="00000-000">

    <label>Cidade</label>
    <input type="text" name="cidade" required>

    <button type="submit"><a href="finalizaado.html">Confirmar Entrega</a></button>
    <br><br><br>

    <a href="Política de Troca e Devolução.docx">Política de Troca e Devolução</a>
</form>
<br><br><br>


<?php
include __DIR__.'/footer.php';
?>