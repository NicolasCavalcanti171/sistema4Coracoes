<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Quatro Corações</title>
  <link rel="stylesheet" href="styles2.css" />
  <link rel="stylesheet" href="php.css">
  <style>
    header nav {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    gap: 20px;
    background-color: #694125;
    padding: 12px 12x;
    }

    header nav a {
    padding: 8px 15px;
    border-radius: 12px;
    transition: 0.3s;
    }

    header nav a:hover {
    background-color: #4b2f1f;
    }
  </style>
</head>
<body>

  <header> 
    <nav>
      <a href="index.html"><img src="logo.png" class="simbolo" alt="Início"></a>
    </nav>
  </header>
