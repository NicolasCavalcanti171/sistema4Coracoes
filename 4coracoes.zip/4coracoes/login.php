<?php
include __DIR__.'/header.php';
session_start();

echo '<form method="post" action="">';
echo '<h2>Login</h2>';
echo '<input type="email" name="email" placeholder="Email" required>';
echo '<input type="password" name="senha" placeholder="Senha" required>';
echo '<button type="submit">Entrar</button>';
echo '<p>Não tem cadastro? <a href="cadastro.php">Cadastre-se aqui</a></p>';
echo '</form>';

$host = 'localhost';
$db = 'sistemalogin';
$user = 'root';
$pass = 'root';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    $stmt = $conn->prepare("SELECT senha FROM usuarios WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hash_senha);
        $stmt->fetch();

        if (password_verify($senha, $hash_senha)) {
            $_SESSION['email'] = $email;

            header("Location: cardapio.html");
            exit;
        } else {
            echo "<p class='erro'>Senha incorreta!</p>";
        }
    } else {
        echo "<p class='erro'>Email não encontrado!</p>";
    }

    $stmt->close();
}

$conn->close();
include __DIR__.'/footer.php';
?>

